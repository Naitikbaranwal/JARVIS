import { Music, Play, Pause } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

const TrendingSongs = () => {
  const [playing, setPlaying] = useState<number | null>(1);

  const songs = [
    { id: 1, name: 'Cyberpunk Vibes 2024', artist: 'AI Generated', uses: '2.4M' },
    { id: 2, name: 'Cinematic Bass Drop', artist: 'Trend Setter', uses: '1.8M' },
    { id: 3, name: 'Phonk Drift Edit', artist: 'Viral Sounds', uses: '980k' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel p-5 relative overflow-hidden"
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-neon-pink/20 rounded-lg">
            <Music className="w-5 h-5 text-neon-pink" />
          </div>
          <h2 className="font-semibold">Trending Audio</h2>
        </div>
        {playing && (
          <div className="flex items-end gap-1 h-4">
            {[1, 2, 3, 4].map((bar) => (
              <motion.div
                key={bar}
                animate={{ height: ['40%', '100%', '40%'] }}
                transition={{ duration: 0.5, repeat: Infinity, delay: bar * 0.1 }}
                className="w-1 bg-neon-pink rounded-t-sm shadow-[0_0_5px_#ff007f]"
              />
            ))}
          </div>
        )}
      </div>

      <div className="space-y-3">
        {songs.map((song) => (
          <div key={song.id} className="flex items-center gap-4 p-3 rounded-xl bg-white/5 border border-white/5 hover:border-neon-pink/30 transition-colors group">
            <button 
              onClick={() => setPlaying(playing === song.id ? null : song.id)}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${playing === song.id ? 'bg-neon-pink text-white shadow-[0_0_10px_#ff007f]' : 'bg-white/10 group-hover:bg-white/20'}`}
            >
              {playing === song.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            </button>
            <div className="flex-1">
              <p className={`text-sm font-medium ${playing === song.id ? 'text-neon-pink drop-shadow-sm' : ''}`}>{song.name}</p>
              <p className="text-xs text-gray-400">{song.artist}</p>
            </div>
            <span className="text-xs font-semibold bg-white/10 px-2 py-1 rounded-md">{song.uses} uses</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default TrendingSongs;
