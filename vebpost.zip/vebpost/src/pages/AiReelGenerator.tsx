import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Play, Film, Sparkles, Wand2, Smartphone, Type, Settings2, Download } from 'lucide-react';
import CaptionGenerator from '../components/widgets/CaptionGenerator';

const AiReelGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [reelReady, setReelReady] = useState(false);
  const [selectedMode, setSelectedMode] = useState('product');
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const modes = [
    { id: 'product', name: 'Product Launch', icon: Sparkles },
    { id: 'sale', name: 'Festival Sale', icon: Settings2 },
    { id: 'promo', name: 'Restaurant Promo', icon: Film },
    { id: 'fashion', name: 'Fashion Brand', icon: Type },
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    setReelReady(false);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsGenerating(false);
            setReelReady(true);
          }, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-outfit">AI Reel Studio</h1>
          <p className="text-gray-400 mt-1">Transform static assets into cinematic viral reels</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Workspace Column */}
        <div className="lg:col-span-2 space-y-6">
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel p-6"
          >
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Wand2 className="w-5 h-5 text-neon-purple" /> Select AI Mode
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {modes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => setSelectedMode(mode.id)}
                  className={`flex flex-col items-center justify-center gap-3 p-4 rounded-xl border transition-all ${
                    selectedMode === mode.id
                      ? 'bg-neon-purple/20 border-neon-purple text-white shadow-[0_0_15px_rgba(176,38,255,0.3)]'
                      : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:border-white/20'
                  }`}
                >
                  <mode.icon className={`w-6 h-6 ${selectedMode === mode.id ? 'text-neon-cyan' : ''}`} />
                  <span className="text-sm font-medium text-center">{mode.name}</span>
                </button>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-panel p-6"
          >
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Upload className="w-5 h-5 text-neon-cyan" /> Upload Assets
            </h2>
            
            <div className="border-2 border-dashed border-white/20 rounded-2xl p-10 flex flex-col items-center justify-center text-center hover:border-neon-cyan/50 hover:bg-neon-cyan/5 transition-all cursor-pointer group">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Upload className="w-8 h-8 text-gray-400 group-hover:text-neon-cyan" />
              </div>
              <p className="text-lg font-medium">Drag & Drop Images/Videos</p>
              <p className="text-sm text-gray-400 mt-2">or click to browse from your device</p>
              <div className="mt-6 flex gap-2">
                <span className="text-xs bg-white/10 px-3 py-1 rounded-full text-gray-300">Max 10 files</span>
                <span className="text-xs bg-white/10 px-3 py-1 rounded-full text-gray-300">4K Supported</span>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button 
                onClick={handleGenerate}
                disabled={isGenerating}
                className="glass-button px-8 py-3 rounded-xl font-bold flex items-center gap-2 text-white bg-gradient-to-r from-neon-purple/50 to-neon-cyan/50 hover:from-neon-purple hover:to-neon-cyan border-none shadow-[0_0_20px_rgba(176,38,255,0.4)] disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Generating AI Magic...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" /> Generate Cinematic Reel
                  </>
                )}
              </button>
            </div>

            {isGenerating && (
              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-neon-cyan animate-pulse">Applying cinematic transitions...</span>
                  <span className="font-bold">{progress}%</span>
                </div>
                <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-neon-purple to-neon-cyan shadow-[0_0_10px_#00f3ff]"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>
            )}
          </motion.div>

          {/* AI Caption Widget included here */}
          <CaptionGenerator />
        </div>

        {/* Preview Column */}
        <div className="space-y-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="glass-panel p-6 flex flex-col items-center"
          >
            <div className="w-full flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-neon-pink" /> Live Preview
              </h2>
              {reelReady && (
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/20 border border-green-500/30">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                  </span>
                  <span className="text-xs font-bold text-green-400">READY</span>
                </div>
              )}
            </div>

            <div className="w-[300px] h-[533px] bg-black rounded-3xl border-[6px] border-gray-800 relative overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.5)]">
              {reelReady ? (
                <>
                  <video 
                    ref={videoRef}
                    src="https://www.w3schools.com/html/mov_bbb.mp4" 
                    className="w-full h-full object-cover"
                    loop
                    playsInline
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  />
                  
                  {/* Cinematic Overlays */}
                  <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80 pointer-events-none"></div>
                  
                  {!isPlaying && (
                    <button 
                      onClick={togglePlay}
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:bg-white/30 transition-colors z-20"
                    >
                      <Play className="w-8 h-8 text-white ml-1" fill="currentColor" />
                    </button>
                  )}
                  
                  <div className="absolute bottom-6 left-4 right-4 z-20 pointer-events-none">
                    <h3 className="font-bold text-white text-shadow-sm">Cinematic {selectedMode} Reel</h3>
                    <p className="text-sm text-gray-200 mt-1">Generated by VibePost AI ✨</p>
                  </div>
                </>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-gray-500 bg-gray-900/50">
                  <Film className="w-12 h-12 mb-4 opacity-50" />
                  <p className="text-sm font-medium">Reel Preview</p>
                  <p className="text-xs mt-1">Upload assets to generate</p>
                </div>
              )}
            </div>

            {reelReady && (
              <div className="w-full mt-6 space-y-3">
                <button 
                  onClick={togglePlay}
                  className="w-full glass-button py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 text-neon-cyan hover:bg-neon-cyan/10"
                >
                  <Play className="w-4 h-4" /> {isPlaying ? 'Pause Preview' : 'Play Live Preview'}
                </button>
                <button className="w-full glass-button py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 text-neon-purple hover:bg-neon-purple/10">
                  <Download className="w-4 h-4" /> Download 4K Reel
                </button>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AiReelGenerator;
