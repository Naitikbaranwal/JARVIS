import { useState } from 'react';
import { Share2, Instagram, Facebook, Youtube, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

const SocialIntegration = () => {
  const [autoUpload, setAutoUpload] = useState(true);

  const platforms = [
    { name: 'Instagram', icon: Instagram, color: 'text-pink-500', connected: true },
    { name: 'YouTube', icon: Youtube, color: 'text-red-500', connected: true },
    { name: 'Facebook', icon: Facebook, color: 'text-blue-500', connected: false },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel p-5 relative overflow-hidden"
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Share2 className="w-5 h-5 text-blue-500" />
          </div>
          <h2 className="font-semibold">Auto-Post Engine</h2>
        </div>
        
        <label className="flex items-center cursor-pointer relative">
          <input type="checkbox" checked={autoUpload} onChange={() => setAutoUpload(!autoUpload)} className="sr-only" />
          <div className={`w-11 h-6 rounded-full transition-colors ${autoUpload ? 'bg-neon-cyan/50' : 'bg-gray-600'}`}>
            <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${autoUpload ? 'translate-x-5 shadow-[0_0_10px_#00f3ff]' : 'translate-x-0.5'}`}></div>
          </div>
        </label>
      </div>

      <div className="space-y-3">
        {platforms.map((p) => (
          <div key={p.name} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
            <div className="flex items-center gap-3">
              <p.icon className={`w-5 h-5 ${p.color}`} />
              <span className="text-sm font-medium">{p.name}</span>
            </div>
            {p.connected ? (
              <span className="flex items-center gap-1 text-xs text-green-400 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Connected
              </span>
            ) : (
              <button className="text-xs bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors">
                Connect
              </button>
            )}
          </div>
        ))}
      </div>
      
      <button className="w-full mt-4 glass-button py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-neon-purple/20 hover:border-neon-purple/50 transition-all text-neon-purple">
        <Share2 className="w-4 h-4" /> Multi-Platform Blast
      </button>
    </motion.div>
  );
};

export default SocialIntegration;
