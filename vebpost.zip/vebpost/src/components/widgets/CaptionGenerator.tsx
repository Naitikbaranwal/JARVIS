import { useState } from 'react';
import { motion } from 'framer-motion';
import { Type, Sparkles, Hash, Copy, CheckCircle2 } from 'lucide-react';

const CaptionGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [caption, setCaption] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setCaption("Transforming the game 🔥✨ Wait till the end for the reveal! Drop a 💯 if you feel the vibe.\n\n#ViralVibes #TrendSetter #AIcreator");
      setIsGenerating(false);
    }, 1500);
  };

  const handleCopy = () => {
    if (!caption) return;
    navigator.clipboard.writeText(caption);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass-panel p-6"
    >
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-yellow-400/20 rounded-lg">
            <Type className="w-5 h-5 text-yellow-400" />
          </div>
          <h2 className="font-semibold text-lg">AI Smart Captions</h2>
        </div>
        <button 
          onClick={handleGenerate}
          disabled={isGenerating}
          className="glass-button px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:text-yellow-400 hover:border-yellow-400/50 transition-colors disabled:opacity-50"
        >
          {isGenerating ? (
             <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          {isGenerating ? 'Writing...' : 'Generate Magic'}
        </button>
      </div>

      <div className="relative">
        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="AI will generate viral Hindi + English captions here..."
          className="w-full bg-white/5 border border-white/10 rounded-xl p-4 min-h-[120px] text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-yellow-400/50 focus:bg-white/10 transition-all resize-none"
        ></textarea>
        
        {caption && (
          <button 
            onClick={handleCopy}
            className="absolute bottom-3 right-3 p-2 rounded-lg bg-black/50 hover:bg-white/20 transition-colors border border-white/10"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
          </button>
        )}
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {['#Viral', '#TrendingNow', '#Marketing', '#AI'].map((tag) => (
          <span key={tag} className="flex items-center gap-1 text-xs bg-white/5 border border-white/10 px-3 py-1.5 rounded-full hover:border-yellow-400/30 cursor-pointer transition-colors text-gray-300 hover:text-white">
            <Hash className="w-3 h-3 text-yellow-400" /> {tag.replace('#', '')}
          </span>
        ))}
      </div>
    </motion.div>
  );
};

export default CaptionGenerator;
