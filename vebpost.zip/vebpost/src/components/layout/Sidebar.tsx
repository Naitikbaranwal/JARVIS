import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Video, BarChart3, Settings, Zap, Sparkles } from 'lucide-react';

const Sidebar = () => {
  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'AI Reel Gen', path: '/reels', icon: Video },
    { name: 'Analytics', path: '/analytics', icon: BarChart3 },
    { name: 'AI Smart Tools', path: '/smart-tools', icon: Zap },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <aside className="w-64 h-screen hidden md:flex flex-col glass-panel rounded-none border-y-0 border-l-0 border-r-glass-border fixed left-0 top-0 z-40 bg-black/40 backdrop-blur-3xl pt-24 pb-6 px-4">
      <div className="absolute top-6 left-6 flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-neon-purple to-neon-cyan flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <span className="text-xl font-bold font-outfit tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
          VibePost<span className="text-neon-cyan">.ai</span>
        </span>
      </div>

      <nav className="flex-1 space-y-2 mt-8">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group ${
                isActive 
                  ? 'bg-white/10 text-white shadow-[inset_0_0_20px_rgba(0,243,255,0.2)] border border-neon-cyan/30' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <item.icon className={`w-5 h-5 ${isActive ? 'text-neon-cyan drop-shadow-[0_0_8px_rgba(0,243,255,0.8)]' : 'group-hover:text-neon-purple transition-colors'}`} />
                <span className="font-medium">{item.name}</span>
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-neon-cyan shadow-[0_0_10px_#00f3ff]" />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="mt-auto p-4 rounded-xl bg-gradient-to-br from-neon-purple/20 to-transparent border border-neon-purple/30 relative overflow-hidden group cursor-pointer">
        <div className="absolute inset-0 bg-hero-glow opacity-30 group-hover:opacity-60 transition-opacity duration-500 animate-pulse-slow"></div>
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-black/50 overflow-hidden border border-white/20">
            <img src="https://i.pravatar.cc/150?img=68" alt="Profile" className="w-full h-full object-cover" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white">Pro Creator</p>
            <p className="text-xs text-neon-pink">Level 42</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
