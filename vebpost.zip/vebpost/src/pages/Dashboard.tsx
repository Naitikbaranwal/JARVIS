import { motion } from 'framer-motion';
import { TrendingUp, Users, MapPin, ArrowUpRight, Activity } from 'lucide-react';
import SocialIntegration from '../components/widgets/SocialIntegration';
import TrendingSongs from '../components/widgets/TrendingSongs';

const Dashboard = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-outfit">Overview</h1>
          <p className="text-gray-400 mt-1">Your AI social media command center</p>
        </div>
        <button className="glass-button px-6 py-2.5 rounded-xl font-medium flex items-center gap-2 text-neon-cyan border-neon-cyan/30 hover:shadow-[0_0_15px_rgba(0,243,255,0.3)]">
          <Activity className="w-4 h-4" />
          <span>Generate Quick AI Post</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Feed / Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* AI Trend Scanner */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-panel p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-neon-purple/20 rounded-lg">
                <TrendingUp className="w-5 h-5 text-neon-purple" />
              </div>
              <h2 className="text-xl font-semibold">AI Trend Scanner</h2>
              <div className="ml-auto flex items-center gap-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neon-pink opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-neon-pink"></span>
                </span>
                <span className="text-sm text-neon-pink font-medium tracking-wide">LIVE</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['#DiwaliSale2024', '#TechGadgets', '#WinterFashion', '#FoodieFinds'].map((tag, i) => (
                <div key={tag} className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 hover:border-neon-cyan/30 transition-colors cursor-pointer group">
                  <div>
                    <p className="font-medium group-hover:text-neon-cyan transition-colors">{tag}</p>
                    <p className="text-xs text-gray-400 mt-1">{12 + i * 4}M views predicted</p>
                  </div>
                  <div className="flex items-center gap-1 text-green-400">
                    <ArrowUpRight className="w-4 h-4" />
                    <span className="text-sm font-semibold">{(98 - i * 5)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Social & Songs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <SocialIntegration />
            <TrendingSongs />
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Creator Leaderboard */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-panel p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-yellow-400/20 rounded-lg">
                <Users className="w-5 h-5 text-yellow-400" />
              </div>
              <h2 className="text-xl font-semibold">Top AI Creators</h2>
            </div>
            
            <div className="space-y-4">
              {[
                { name: 'Aisha Sharma', niche: 'Fashion', views: '2.4M', avatar: '1' },
                { name: 'Tech Bro', niche: 'Tech', views: '1.8M', avatar: '2' },
                { name: 'Foodie Pro', niche: 'Food', views: '1.2M', avatar: '3' },
              ].map((creator, i) => (
                <div key={creator.name} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer">
                  <div className="font-bold text-gray-500 w-4">#{i + 1}</div>
                  <img src={`https://i.pravatar.cc/150?img=${creator.avatar}`} alt={creator.name} className="w-10 h-10 rounded-full border border-white/20" />
                  <div className="flex-1">
                    <p className="font-medium text-sm">{creator.name}</p>
                    <p className="text-xs text-gray-400">{creator.niche}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-neon-cyan">{creator.views}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Viral Heatmap */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-panel p-6"
          >
             <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-neon-pink/20 rounded-lg">
                <MapPin className="w-5 h-5 text-neon-pink" />
              </div>
              <h2 className="text-xl font-semibold">Viral Heatmap</h2>
            </div>
            
            <div className="space-y-3">
              {[
                { city: 'Mumbai', heat: 98, color: 'bg-red-500' },
                { city: 'Delhi', heat: 85, color: 'bg-orange-500' },
                { city: 'Bangalore', heat: 72, color: 'bg-yellow-500' },
                { city: 'Lucknow', heat: 64, color: 'bg-green-500' },
              ].map((loc) => (
                <div key={loc.city} className="space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-300">{loc.city}</span>
                    <span className="font-medium">{loc.heat}%</span>
                  </div>
                  <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${loc.heat}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                      className={`h-full ${loc.color} shadow-[0_0_10px_currentColor]`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
