import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { BarChart3, TrendingUp, Users, Target } from 'lucide-react';

const data = [
  { name: 'Mon', engagement: 4000, reach: 2400 },
  { name: 'Tue', engagement: 3000, reach: 1398 },
  { name: 'Wed', engagement: 2000, reach: 9800 },
  { name: 'Thu', engagement: 2780, reach: 3908 },
  { name: 'Fri', engagement: 1890, reach: 4800 },
  { name: 'Sat', engagement: 2390, reach: 3800 },
  { name: 'Sun', engagement: 3490, reach: 4300 },
];

const Analytics = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-outfit">AI Analytics</h1>
        <p className="text-gray-400 mt-1">Deep dive into your viral performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { title: 'Total Reach', value: '2.4M', icon: Users, color: 'text-neon-cyan', bg: 'bg-neon-cyan/20' },
          { title: 'Engagement Rate', value: '14.2%', icon: Target, color: 'text-neon-purple', bg: 'bg-neon-purple/20' },
          { title: 'AI Viral Score', value: '94/100', icon: TrendingUp, color: 'text-neon-pink', bg: 'bg-neon-pink/20' },
          { title: 'Conversion', value: '4.8%', icon: BarChart3, color: 'text-yellow-400', bg: 'bg-yellow-400/20' },
        ].map((stat, i) => (
          <motion.div 
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-panel p-5 relative overflow-hidden group"
          >
            <div className={`absolute -right-4 -top-4 w-20 h-20 ${stat.bg} blur-2xl group-hover:scale-150 transition-transform duration-500`}></div>
            <div className="flex items-center gap-3 mb-4 relative z-10">
              <div className={`p-2 rounded-lg ${stat.bg}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <h3 className="text-sm font-medium text-gray-400">{stat.title}</h3>
            </div>
            <p className="text-3xl font-bold font-outfit relative z-10">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="glass-panel p-6 h-[400px]"
        >
          <h2 className="text-xl font-semibold mb-6">Reach Growth Prediction</h2>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorReach" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f3ff" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#00f3ff" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
              <XAxis dataKey="name" stroke="#888" tickLine={false} axisLine={false} />
              <YAxis stroke="#888" tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(0,243,255,0.3)', borderRadius: '12px' }}
                itemStyle={{ color: '#00f3ff' }}
              />
              <Area type="monotone" dataKey="reach" stroke="#00f3ff" strokeWidth={3} fillOpacity={1} fill="url(#colorReach)" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="glass-panel p-6 h-[400px]"
        >
          <h2 className="text-xl font-semibold mb-6">Engagement Analysis</h2>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
              <XAxis dataKey="name" stroke="#888" tickLine={false} axisLine={false} />
              <YAxis stroke="#888" tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(176,38,255,0.3)', borderRadius: '12px' }}
              />
              <Line type="monotone" dataKey="engagement" stroke="#b026ff" strokeWidth={3} dot={{ r: 4, fill: '#b026ff', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 6, fill: '#b026ff' }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
};

export default Analytics;
