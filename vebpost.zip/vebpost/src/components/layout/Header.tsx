import { Bell, Search, Flame, Coins } from 'lucide-react';

const Header = () => {
  return (
    <header className="h-20 fixed top-0 right-0 left-0 md:left-64 z-30 glass-panel rounded-none border-x-0 border-t-0 bg-black/20 backdrop-blur-xl flex items-center justify-between px-6 md:px-10">
      <div className="relative w-64 md:w-96 hidden sm:block">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search AI trends, sounds..." 
          className="w-full bg-white/5 border border-white/10 rounded-full py-2 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-neon-purple/50 focus:bg-white/10 transition-all placeholder-gray-500"
        />
      </div>

      <div className="flex items-center gap-4 ml-auto">
        {/* Streak */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30">
          <Flame className="w-4 h-4 text-orange-500 drop-shadow-[0_0_8px_rgba(249,115,22,0.8)]" />
          <span className="text-sm font-bold text-white">14</span>
        </div>

        {/* Coins */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-yellow-400/20 to-amber-500/20 border border-yellow-400/30">
          <Coins className="w-4 h-4 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]" />
          <span className="text-sm font-bold text-white">2.4k</span>
        </div>

        <button className="relative p-2 rounded-full hover:bg-white/10 transition-colors">
          <Bell className="w-5 h-5 text-gray-300" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-neon-pink shadow-[0_0_8px_#ff007f]"></span>
        </button>

        <button className="md:hidden glass-button px-4 py-2 rounded-lg text-sm font-medium">
          Menu
        </button>
      </div>
    </header>
  );
};

export default Header;
